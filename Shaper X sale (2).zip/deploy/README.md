# Velq — static site

One file: `index.html`. All images, fonts and code are inlined. No build step, no database.

## Hostinger Git auto-deploy

1. hPanel -> Websites -> your domain -> **Advanced -> GIT**
2. **Repository**: `https://github.com/<you>/velq-site.git`
3. **Branch**: `main`
4. **Directory**: leave EMPTY (deploys to public_html root)
5. Click **Create**, then **Deploy** once manually to confirm it works.
6. Click the **Auto deployment** / webhook icon and copy the URL.
7. GitHub repo -> Settings -> Webhooks -> Add webhook
   - Payload URL: the Hostinger URL
   - Content type: `application/json`
   - Event: just the push event
   - Save.

Every push to `main` now redeploys automatically.

## Updating

Replace `index.html` with the new build, then:

```
git add index.html
git commit -m "Update site"
git push
```

## Notes

- `index.html` is ~12 MB because photography is inlined. GitHub's per-file limit is 100 MB, so this is fine, but pushes are not instant.
- Hard-refresh (Cmd/Ctrl+Shift+R) after a deploy — browsers cache aggressively.
- Forms (email capture, contact, reserve) are front-end only; they confirm visually but do not send anything yet.
